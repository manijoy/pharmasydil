const data={
    products: [
        {   id:'1',
            name:'Topaz 25 Tablet',
            price:123.4,
            image: 'https://onemg.gumlet.io/image/upload/l_watermark_346,w_480,h_480/a_ignore,w_480,h_480,c_fit,q_auto,f_auto/v1600210163/cropped/gtxp33sousejqxiagxhe.png'
        },
        {   id:'2',
            name:'Azithral 500 Tablet',
            price:450.7,
            image: 'https://onemg.gumlet.io/image/upload/l_watermark_346,w_480,h_480/a_ignore,w_480,h_480,c_fit,q_auto,f_auto/v1600151182/cropped/kqkouvaqejbyk47dvjfu.jpg'
        },
        {   id:'3',
            name:'Allegra 120mg Tablet',
            price:65,
            image: 'https://onemg.gumlet.io/image/upload/l_watermark_346,w_480,h_480/a_ignore,w_480,h_480,c_fit,q_auto,f_auto/v1600084406/cropped/b949nty485o1itezg3ya.jpg'
        },
        {   id:'4',
            name:'Avil 25 Tablet',
            price:98.5,
            image: 'https://onemg.gumlet.io/image/upload/l_watermark_346,w_480,h_480/a_ignore,w_480,h_480,c_fit,q_auto,f_auto/v1600084529/cropped/mmsye6bf97tkcocat24j.jpg'
        },
        {   id:'5',
            name:'Atarax 25mg Tablet',
            price:235.9,
            image: 'https://onemg.gumlet.io/image/upload/l_watermark_346,w_480,h_480/a_ignore,w_480,h_480,c_fit,q_auto,f_auto/v1600110853/cropped/v9py58kciridvbi7bqls.jpg'
        },
        {   id:'6',
            name:'Ketoadd Tablet',
            price:110,
            image: 'https://onemg.gumlet.io/image/upload/l_watermark_346,w_480,h_480/a_ignore,w_480,h_480,c_fit,q_auto,f_auto/v1600107921/cropped/f85ol5ublkqui0h4t38h.jpg'
        },
        {   id:'7',
            name:'KZ Cream',
            price:70,
            image: 'https://onemg.gumlet.io/image/upload/l_watermark_346,w_480,h_480/a_ignore,w_480,h_480,c_fit,q_auto,f_auto/v1600081116/cropped/ldm4w5ibbuoy5zb03uoo.jpg'
        },
        {   id:'8',
            name:'Grilinctus-BM Syrup',
            price:169.4,
            image: 'https://onemg.gumlet.io/image/upload/l_watermark_346,w_480,h_480/a_ignore,w_480,h_480,c_fit,q_auto,f_auto/v1600083643/cropped/yirp6sspr3jbm8por3ug.jpg'
    },

        {   id:'9',
            name:'Endogest 200 SR Tablet',
            price:79.2,
            image: 'https://onemg.gumlet.io/image/upload/l_watermark_346,w_480,h_480/a_ignore,w_480,h_480,c_fit,q_auto,f_auto/v1600065758/cropped/l80srtiazi6hiqhjxzzp.jpg'
},
        {   id:'10',
            name:'Meprate 10mg Tablet',
            price:82.1,
            image: 'https://onemg.gumlet.io/image/upload/l_watermark_346,w_480,h_480/a_ignore,w_480,h_480,c_fit,q_auto,f_auto/v1611928680/upmfvpl8aywuzf6xgxcx.jpg'
},
        {   id:'11',
            name:'Voveran SR 100 Tablet',
            price:560,
            image: 'https://onemg.gumlet.io/image/upload/l_watermark_346,w_480,h_480/a_ignore,w_480,h_480,c_fit,q_auto,f_auto/v1600091840/cropped/s9ycpnw9hw9cibuyyaoa.jpg'
        },
        {   id:'12',
            name:'Januvia 100mg Tablet',
            price:499,
            image: 'https://onemg.gumlet.io/image/upload/l_watermark_346,w_480,h_480/a_ignore,w_480,h_480,c_fit,q_auto,f_auto/v1600081010/cropped/tylw7gc7xhvlqetdlvji.jpg'
        },
    ],
};

export default data;